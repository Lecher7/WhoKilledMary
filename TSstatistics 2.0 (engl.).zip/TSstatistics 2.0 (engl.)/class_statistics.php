<?php


/************************************************
*												*
*	TSstatistics 2.0							*
*												*
*	by Thomas Schuster							*
*	http://www.TSinter.net						*
*												*
*												*
*	This class combines the functionality of a	*
*	visitor counter, a pageimpression counter	*
*	and a log system.							*
*												*
************************************************/


class TSstatistics extends SupportFunctions {


	// The $DOCUMENT_ROOT has to be written out as /homepages/xx/xxx/htdocs/xxx.
	// This makes it possible to include this script in every webpage of the website,
	// regardless of the directory it is stored in.
	var $log_data = "/homepages/xx/xxx/htdocs/xx/path-to-file/log.dat";
	var $visitor_data = "/homepages/xx/xxx/htdocs/xxx/path-to-file/visitor.dat";
	var $pageImpressions_data = "/homepages/xx/xxx/htdocs/xxx/path-to-file/pageImpressions.dat";
	var $browser_data = "/homepages/xx/xxx/htdocs/xxx/path-to-file/browser.dat";
	var $ip;
	var $browser;
	var $webpage;
	var $sessionID;
	var $visitors;
	
	

	// constructor
	function TSstatistics($ip, $user_agent, $webpage, $sessionID) {
		$this->ip = $ip;
		$this->webpage = $webpage;
		$this->browser = $this->_checkBrowser($user_agent);
		$this->sessionID = $sessionID;
		
		$this->visitors = $this->_countVisitors();
	}


	// check for cookie support
	function _cookieCheck() {
		global $visitorLogged;
		if (!isset($visitorLogged))
			return FALSE;
		else return TRUE;
	}


	// count visitors
	function _countVisitors() {

		# If someone enters the website, no session variables are set
		# => cookieCheck returns FALSE.
		
		# If cookieCheck returns TRUE, the visitor has reloaded the
		# webpage and his browser supports cookies. In that case he
		# was already counted when he entered the website, so nothing
		# has to be done and there is no need for an else tree.

		if ($this->_cookieCheck() == FALSE) {

			# Check in the log_data, if the last visitor without cookie-
			# support reloaded a webpage or if a new visitor entered the
			# website.

			# Compare IP with stored IP from file. If the IP's differ,
			# then increment number of visitors, because a new user
			# has entered the website.

			$log_file = file($this->log_data);
			$i = sizeof($log_file) - 1;
			$log_line = explode("|", $log_file[$i]);
			if (strcmp($log_line[1], $this->ip))
				$this->_incrementNumberOfVisitors();

			# Log the name of the browser.
			$this->_logBrowser();
		}
		
		return $this->_getNumberOfVisitors();
		
	}


	function _getNumberOfVisitors() {
		$visitor_file = file($this->visitor_data);
		$visitor_line = explode("|", $visitor_file[0]);
		$numberOfVisitors = $visitor_line[0];
		return $numberOfVisitors;
	}


	function _incrementNumberOfVisitors() {
		$numberOfVisitors = $this->_getNumberOfVisitors();
		# increment number of visitors and store data
		$numberOfVisitors++;
		$visitor_line = "$numberOfVisitors|\r\n";
		$this->_writeLine($this->visitor_data, $visitor_line, "w");
		# mark visitor as logged IN THIS SESSION
		return 1;
	}


	// count page impressions
	function _countPageImpressions() {
		$pageImpressions_file = file($this->pageImpressions_data);
		
		# This Function checks whether there is already an entry for the webpage
		# in the pageImpressions_data. If there is one, it will increment the number
		# of page impressions. If there is none, it will add a new entry with the
		# actual date and initialize the number of page impressions of that webpage with 1.

		if ($this->_incrementIfEqual($this->webpage, $pageImpressions_file, 0, 1) != 1) {
			# there is no entry yet, so we have to add a new one
			$time = date('d.m.Y');
			$line = "$this->webpage|1|$time|\r\n";
			$this->_writeLine($this->pageImpressions_data, $line, "a");
		}
		else {
			# write the already changed array back to the pageImpressions_data
			$this->_writeArray($this->pageImpressions_data, $pageImpressions_file, "w");
		}
		return 1;
	}


	function _getNumberOfPageImpressions() {
		$pageImpressions_file = file($this->pageImpressions_data);
		for ($i = 0; $i < sizeof($pageImpressions_file); $i++) {
			$pageImpressions_line = explode("|", $pageImpressions_file[$i]);
			if (!strcmp($pageImpressions_line[0], $this->webpage)) {
				return $pageImpressions_line[1];
				break;
			}
		}
	}


	// log visitors way through website
	function _logVisitors() {

		# If browser does not support cookies, every pageimpression
		# is logged in a single line in the log_data. It is not possible
		# to log a visitors way through the website via IP-matching, because
		# IP's are not unique and many visitors get the same IP because they
		# have the same provider (of course not at the same time!).

		# Even if the browser supports cookies, the first time a visitor enters
		# the website the cookieCheck return FALSE because the session variables
		# are only visible on page reload.

		if ($this->_cookieCheck() == FALSE) {
		
			$host = gethostbyaddr($this->ip);
			$time = date('d.m.Y \u\m H:i');
			$log_line = "no cookie|$this->ip|$host|$this->browser|$time|$this->webpage|\r\n";
			$this->_writeLine($this->log_data, $log_line, "a");
			$visitorLogged = 1;
		}
		else {
			
			# Browser supports cookies and actual session has already been logged
			# when the visitor has entered the website.
			# So we search for the sessionID (second or more reload) or the IP (first reload)
			# in the log_data and add the actual webpage to the list.
			# On first reload there cannot exist a sessionID in the log_data, because this
			# sessionID is produced on first reload and not earlier.

			$log_file = file($this->log_data);
			for ($i = sizeof($log_file) - 1; $i > 0; $i--) {
				$log_line = explode("|", $log_file[$i]);
				if (!strcmp($this->sessionID, $log_line[0]) || !strcmp($this->ip, $log_line[1])) {
					$index = sizeof($log_line) - 1;
					# replace "no cookie" with the sessionID on first page reload and add the new webpage
					$log_line[0] = $this->sessionID;
					$log_line[$index] = "$this->webpage|\r\n";
					$log_file[$i] = implode("|", $log_line);
					$this->_writeArray($this->log_data, $log_file, "w");
					$visitorLogged = 1;
					break;
				}
			}
			
		}
		return $visitorLogged;
	}


	// check browser
	function _checkBrowser($user_agent) {

        $browser = "unbekannt";
		
		preg_match_all("/(microsoft internet explorer|msie|netscape6|mozilla|opera|konqueror|icab|lynx|ncsa mosaic|amaya|omniweb)[\/\sa-z]*([0-9]+)([\.0-9a-z]+)/i", $user_agent, $matches);

		for ($i = 0; $i < sizeof($matches[0]); $i++) {
			if (eregi("opera", $matches[0][$i])) {
				if (!$matches[3][$i])
					$matches[3][$i] = ".0";
				$browser = "Opera ".$matches[2][$i].$matches[3][$i];
			}
			else if (eregi("MSIE", $matches[0][$i])) {
				if (!$matches[3][$i])
					$matches[3][$i] = ".0";
				$browser = "Internet Explorer ".$matches[2][$i].$matches[3][$i];
			}
			else if (eregi("Netscape6", $matches[0][$i])) {
				if (!$matches[3][$i])
					$matches[3][$i] = ".0";
				$browser = "Netscape ".$matches[2][$i].$matches[3][$i];
			}
			else if (eregi("Gecko", $matches[0][$i])) {
				if (!$matches[3][$i])
					$matches[3][$i] = ".0";
				$browser = "Mozilla(Gecko) ".$matches[2][$i].$matches[3][$i];
			}
			else if (eregi("Mozilla/4", $matches[0][$i])) {
				if (!$matches[3][$i])
					$matches[3][$i] = ".0";
				$browser = "Netscape Communicator ".$matches[2][$i].$matches[3][$i];
			}
		}
		return $browser;
	}


	// log the client browser
	function _logBrowser() {
		$browser_file = file($this->browser_data);
		if ($this->_incrementIfEqual($this->browser, $browser_file, 0, 1) != 1) {
			$line = "$this->browser|1|\r\n";
			$this->_writeLine($this->browser_data, $line, "a");
		}
		else {
			$this->_writeArray($this->browser_data, $browser_file, "w");
		}
		return 1;
	}

	// prepare the output of the statistics
	function _getSortedStatistics($sort_file) {

		# Return the sorted statistics like a sql-table with two columns.
		# The first column contains the name of the subject and the second column
		# contains the corresponding number of hits. This is realized through a
		# two-dimensional array.

		$sort_file = file($sort_file);
	
		for ($i = 0; $i < sizeof($sort_file); $i++) {
			$sort_line = explode("|", $sort_file[$i]);

			# Find out how many columns exist.
			# Important: The last column contains always the \r\n !

			switch (sizeof($sort_line)) {
				case 2:
					# Fill the first column of the table.
					$sort_array[0][$i] = $sort_line[0];
					array_multisort ($sort_array[0]);
					break;
				case 3:
					# Fill the first column of the table.
					$sort_array[0][$i] = $sort_line[0];
					# Fill the second column of the table.
					$sort_array[1][$i] = $sort_line[1];
					# Sort the table according to the second column (the hits).
					array_multisort ($sort_array[1], SORT_NUMERIC, SORT_DESC, $sort_array[0]);
					break;
				case 4:
					# Fill the first column of the table.
					$sort_array[0][$i] = $sort_line[0];
					# Fill the second column of the table.
					$sort_array[1][$i] = $sort_line[1];
					# Fill the third column of the table.
					$sort_array[2][$i] = $sort_line[2];
					# Sort the table according to the second column (the hits).
					array_multisort ($sort_array[1], SORT_NUMERIC, SORT_DESC, $sort_array[0], $sort_array[2]);
					break;
			}

		}

		return $sort_array;
	}


	function _getUserTrack() {
		$log_file = file($this->log_data);
		for ($i = sizeof($log_file) - 1; $i > 0; $i--) {
			$log_line = explode("|", $log_file[$i]);
			if (!strcmp($log_line[0], $this->sessionID) || !strcmp($log_line[1], $this->ip)) {
				$log_array["host"] = $log_line[2];
				$log_array["date"] = $log_line[4];
				$log_array["browser"] = $this->browser;
				$log_array["sessionID"] = $this->sessionID;
				$log_array["ip"] = $this->ip;
				for ($i = 5; $i < sizeof($log_line); $i++)
					$log_array["webpages"][$i - 5] = $log_line[$i];
			}
		}
		return $log_array;
	}



}

?>	