<?php

// If the client browser supports cookies, TSstatistics will use session management.
session_start();
session_register("visitorLogged");

?>

<!-- userspezifisches stylesheet -->
<link rel="stylesheet" href="statistics.css" type="text/css">
<center>

<?php

include("class_support.php");
include("class_statistics.php");

// Instanciate a new object, the constructor automatically counts the visitors and
// the browser.
$statistics = new TSstatistics($REMOTE_ADDR, $HTTP_USER_AGENT, $PHP_SELF, $PHPSESSID);


// Track the user's way through the website.
$visitorLogged = $statistics->_logVisitors();

echo("The following output demonstrates the functionality of TSstatistics. This can easily
      be formated with html-templates.<br><br><br>");

// Display the actual visitor number.
echo($statistics->visitors." visitors");


echo("<br><hr><br>Browser statistics<br><br>");


// Get the actual browser statistics.
$browser_array = $statistics->_getSortedStatistics($statistics->browser_data);
$browserNames = $browser_array[0];
$hits = $browser_array[1];

?>

  <table class="tableBrowser" cellspacing="0">
    <tr> 
      <td colspan="2" class="tdHeadline">Browser</td>
    </tr>
    <?php

    // Display the actual browser statistics.
    for ($i = 0; $i < sizeof($browserNames); $i++) {
      ?>
      <tr> 
        <td class="tdBrowserName"><?php echo($browserNames[$i]); ?></td>
        <td class="tdBrowserHits"><?php echo($hits[$i]); ?> Hits</td>
      </tr>
      <?php
    }
    ?>
  </table>

<br><hr><br>Page impressions statistics<br><br>

<?php

// Get the actual page impressions statistics.
$pageImpressions_array = $statistics->_getSortedStatistics($statistics->pageImpressions_data);
$pageNames = $pageImpressions_array[0];
$pageImpressions = $pageImpressions_array[1];
$date = $pageImpressions_array[2];

?>

  <table class="tableImpressions" cellspacing="0">
    <tr> 
      <td colspan="3" class="tdHeadline">Page impressions</td>
    </tr>
    <?php

    // Display the actual page impressions statistics.
    for ($i = 0; $i < sizeof($pageNames); $i++) {
      ?>
      <tr> 
        <td class="tdImpressionsName"><?php echo($pageNames[$i]); ?></td>
        <td class="tdImpressionsHits"><?php echo($pageImpressions[$i]); ?> Hits</td>
        
      <td class="tdImpressionsDate">since 
        <?php echo($date[$i]); ?>
      </td>
      </tr>
      <?php
    }
    ?>
  </table>

<br><hr><br>User track:<br><br>

<?php

// Get the user track
$user_track = $statistics->_getUserTrack();

?>

  <table class="tableTrack" cellspacing="0">
    <tr> 
      <td class="tdHeadline">Session ID</td>
      <td class="tdHeadline"><?php echo($user_track["sessionID"]); ?></td>
    </tr>
    <tr> 
      <td class="tdHeadline">IP</td>
      <td class="tdHeadline"><?php echo($user_track["ip"]); ?></td>
    </tr>
    <tr> 
      <td class="tdHeadline">Host</td>
      <td class="tdHeadline"><?php echo($user_track["host"]); ?></td>
    </tr>
    <tr> 
      <td class="tdHeadline">Browser</td>
      <td class="tdHeadline"><?php echo($user_track["browser"]); ?></td>
    </tr>
    <tr> 
      <td class="tdHeadline">Date</td>
      <td class="tdHeadline"><?php echo($user_track["date"]); ?></td>
    </tr>
    <?php

    // Display the track of the actual user
    for ($i = 0; $i < sizeof($user_track["webpages"]) - 1; $i++) {
      ?>
      <tr> 
        <td class="tdTrackNo"> Requested webpage no. <?php echo($i + 1); ?></td>
        <td class="tdTrackName"><?php echo($user_track["webpages"][$i]); ?></td>
      </tr>
      <?php
    }
    ?>
  </table>

  <table cellspacing="0">
    <tr>
      <td class="tdCopyright"> 
        <a href="http://www.tsinter.net/source/statistics/version_2/index.php?language=us" target="_self">TS<i>statistics</i></a>� 
        �2001 
        <a href="http://www.TSinter.net" target="blank">TSinter.net</a>
      </td>
    </tr>
  </table>

</center>