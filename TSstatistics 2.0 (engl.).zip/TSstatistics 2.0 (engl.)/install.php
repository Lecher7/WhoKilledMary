<?php


// If the client browser supports cookies, TSstatistics will use session management.
session_start();
session_register("visitorLogged");

// *** You have to edit this! ***
// It is important to add the $DOCUMENT_ROOT. That makes it possible to include
// the classes in every webpage of your site, regardless of the directory your
// webpage is stored in.
include("$DOCUMENT_ROOT/path-to-file/class_support.php");
include("$DOCUMENT_ROOT/path-to-file/class_statistics.php");

// Instanciate a new object, the constructor automatically counts the visitors and
// the browser.
$statistics = new TSstatistics($REMOTE_ADDR, $HTTP_USER_AGENT, $PHP_SELF, $PHPSESSID);

// Track the user's way through the website.
$visitorLogged = $statistics->_logVisitors();

?>